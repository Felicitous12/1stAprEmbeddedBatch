/* 
 * File:   canbuffers.h
 * Author: HP
 *
 * Created on 15 May, 2022, 6:53 PM
 */

#ifndef CANBUFFERS_H
#define	CANBUFFERS_H

#ifdef	__cplusplus
extern "C" {
#endif

void can_tx(void);
void can_rx(void);

#ifdef	__cplusplus
}
#endif

#endif	/* CANBUFFERS_H */

