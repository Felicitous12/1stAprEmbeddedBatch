/* 
 * File:   caninitialisation.h
 * Author: HP
 *
 * Created on 15 May, 2022, 1:39 PM
 */

#ifndef CANINITIALISATION_H
#define	CANINITIALISATION_H

#ifdef	__cplusplus
extern "C" {
#endif

unsigned char can_frame[13];
void can_tx_init(void);
void can_rx_init(void);
void can_init(void);
void system_init(void);


#ifdef	__cplusplus
}
#endif

#endif	/* CANINITIALISATION_H */

