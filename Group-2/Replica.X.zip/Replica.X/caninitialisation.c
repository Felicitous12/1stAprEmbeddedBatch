#include<xc.h>

#define ENABLE 1
#define DISABLE 0

void system_init()
{
    /* CAN_TX = RB2, CAN_RX = RB3 */
	TRISBbits.RB2 = DISABLE;				/* CAN TX */
	TRISBbits.RB3 = ENABLE;					/* CAN RX */
    
    /*CONFIG THE GENERAL INTERUPPT*/
    GIE = ENABLE;
    PEIE = ENABLE;
    
    /*CONFIG THE CAN INTERUPPT*/
    PIE3bits.RXB0IE = ENABLE;
    IPR3bits.RXB0IP = ENABLE;
    
}
void can_init()
{
	CANCON = 0x80;                       	/* set new mode configuration mode */

	/* Wait untill desired mode is set */
	while (CANSTAT != 0x80);                //1000 for Configuration mode    000 = No interrupt 

	BRGCON1 = 0xC1;							/* 1100 0001  */
	BRGCON2 = 0xAE;							/* 1010 1110   */
	BRGCON3 = 0x45;							/* 0100 0101  */
    
    CIOCON = 0x20;                         /*CAN I/O CONTROL REGISTER */
    
/* Enter CAN module into Normal mode */
	CANCON = 0x00;                          // 0000 for normal mode
    
}


void can_rx_init()
{
    CANCON = 0x0C;                                                        // 0000 for normal mode for receive buffer0
    
    
     /* ENABLE FILERS *FILTER 0*/
    RXF0SIDH = 0X4C;						                               /*receive the msg id 265...*/
    RXF0SIDL = 0XA0;
       
 /*ENABLE MASK*/
    RXM0SIDH = 0XFF;                                                      /*strict filter we are using here..*/
    RXM0SIDL = 0XE0;

 /* SET RECEICVE MODE FOR BUFFERS */
    RXB0CON = 0X00;                         
    
}


void can_tx_init()
{ 
    CANCON = 0x08;                                                       /*in normal mode to transmit buffer 0*/    
}

