#include<xc.h>
#include "canbuffers.h"
#define _XTAL_FREQ 20000000
unsigned char can_frame[13];
unsigned char  counter;
      


 void can_tx()                                                             /* transmitting the msgID 42 (engine module) */
{       
     counter=counter+1;														/*taking the counter for contineous increament of the*/
	                                                                        /*speed bytes and engine torque bytes*/
     
    TXB0CON =0X00;                                                         //Set bits for transmit control register 
    TXB0SIDH =0x08;                                                        //set transmit buffer for standard identifier high byte 
    TXB0SIDL =0X42;                                                        //set transmit buffer for standard identifier low byte 
    TXB0DLC =0X08;                                                         //set transmit buffer for data length code
    TXB0D0 = counter;                                                      /* engine torque byte [0]data to  transmit */ 
    TXB0D1 = counter;                                                      /* engine torque byte [1] data to  transmit */
    TXB0D2 = counter;                                                      /* engine torque byte [2] data to  transmit */ 
    TXB0D3 = 0x00;                                                         /* engine torque byte [3] data to  transmit */
    TXB0D4 = ( can_frame[9] -  can_frame[10] );                            /* cruise control distance delta data byte [4] */
    TXB0D5 = counter;                                                      /* speed byte [0] data byte [5] of ENM */
    TXB0D6 = counter;                                                      /* speed byte [1] data byte [6] of ENM */
    TXB0D7 = counter;                                                      /* speed byte [2] data byte [7] of ENM */
    TXB0CONbits.TXREQ =1;                                                  /*setting the buffer to transmit  */
     __delay_ms(1000);													   /*giving the cyclic time*/	
  }

 
 void can_rx()
{   
    /*Checking Receive buffer contains a received message or not*/
   
   if (RXB0CONbits.RXB0FUL)
    {
       can_frame[0] = RXB0DLC;  
       can_frame[1] = RXB0SIDL;
       can_frame[2] = RXB0SIDH;
       can_frame[3] = RXB0D0;                                     
       can_frame[4] = RXB0D1;        
       can_frame[5] = RXB0D2;        
       can_frame[6] = RXB0D3;             
       can_frame[7] = RXB0D4;              
       can_frame[8] = RXB0D5;                      
       can_frame[9] = RXB0D6;                     /*receiving the front object distance byte 0*/
       can_frame[10] = RXB0D7;                    /*receiving the front object distance byte 1*/       
    }
    
}

