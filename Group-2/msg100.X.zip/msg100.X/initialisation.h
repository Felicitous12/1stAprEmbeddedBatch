/* 
 * File:   initialisation.h
 * Author: HP
 *
 * Created on 15 May, 2022, 9:30 PM
 */

#ifndef INITIALISATION_H
#define	INITIALISATION_H

#ifdef	__cplusplus
extern "C" {
#endif

void system_init(void);
void can_init(void);
void can_rx_init(void);
void can_tx_init(void);


#ifdef	__cplusplus
}
#endif

#endif	/* INITIALISATION_H */

