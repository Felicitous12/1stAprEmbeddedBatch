#include"CanBuffers.h"
#include<xc.h>
#define ENABLE  1
#define DISABLE 0
#define _XTAL_FREQ 20000000

unsigned char can_frame[13];



/* 0x42 engine management data and passing into 0x100 srs node*/
   void can_tx()
{  
       
    TXB0CON =0X00;       //Set bits for transmit control register 
    TXB0SIDH =0X20;      //set transmit buffer for standard identifier high byte 
    TXB0SIDL =0X00;   //set transmit buffer for standard identifier low byte 
    TXB0DLC =0X08;       //set transmit buffer for data length code
    TXB0D0 =can_frame[3];        //data to  transmit 
    TXB0D1 =can_frame[4];        //data to  transmit 
    TXB0D2 =can_frame[5];        //data to  transmit 
    TXB0D3 =can_frame[6];        //data to  transmit
    TXB0D4 =can_frame[7];        //data to  transmit
    TXB0D5 =can_frame[8];        //data to  transmit
    TXB0D6 =can_frame[9];        //data to  transmit
    TXB0D7 =can_frame[10];        //data to  transmit
    TXB0CONbits.TXREQ =1;          //setting the buffer to transmit
    if(TXB0D0 == 0x01)
        PORTCbits.RC1=ENABLE;
     __delay_ms(1000);



}

void can_rx()
{   
    /*Checking Receive buffer contains a received message or not*/
    PORTCbits.RC0= DISABLE;
    if (RXB0CONbits.RXB0FUL)
    {
       can_frame[0] = RXB0DLC;  
       can_frame[1] = RXB0SIDL;
       can_frame[2] = RXB0SIDH;
       can_frame[3] = RXB0D0;
       can_frame[4] = RXB0D1;
       can_frame[5] = RXB0D2;
       can_frame[6] = RXB0D3;
       can_frame[7] = RXB0D4;
       can_frame[8] = RXB0D5;
       can_frame[9] = RXB0D6;
       can_frame[10] = RXB0D7;
    }

}

