/* 
 * File:   main.h
 * Author: HP
 *
 * Created on 15 May, 2022, 9:36 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif

#include"CanBuffers.h"
#include"initialisation.h"    


#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

